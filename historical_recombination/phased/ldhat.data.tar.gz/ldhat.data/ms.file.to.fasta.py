from common import *
import sys
import json
a = get_file(sys.argv[1], '%%%%%%%%%%%%%%%%%%%', buffered=1)

idx = 0
xvals, yvals = {},{}
seg_sites = {}
pos = {}
n = []
ctr = 0
true_idx = 0
bad_idx = []
for i in a:
    if 'segsites' in i[0]:
        seg_sites[true_idx] = int(i[0].split()[-1])
    if 'positions' in i[0]:
        pos[true_idx] = [float(jj) for jj in i[0].split()[1:]]
    if './ms' in i[0]:
        true_idx+=1
        idx = 0
        theta_line = i[0].split()
        #print theta_line
        ms_vals = map(float, [theta_line[4], theta_line[6]])
        if ms_vals[0] < 3: bad_idx.append(true_idx)
        yvals[true_idx] = ms_vals
    if 5 < idx < 56:
        n.append(i[0])
    if len(n) == 50:
        xvals[true_idx] =  n
        idx = 0
        n = []
        if not true_idx % 100: print true_idx, len(xvals), len(yvals), min(xvals), max(xvals), min(yvals), max(yvals) #xvals[max(xvals)].shape, seg_sites[max(seg_sites)]
        #if len(xvals) != len(yvals):
        #    print true_idx, idx, len(xvals), len(yvals), xvals[-2].shape, yvals[-2], '*********'
    #print idx
    idx+=1

bad_idx = set(bad_idx)

for i in seg_sites:
    if seg_sites[i] == 0:
        bad_idx.add(i)

ok = sorted(set(seg_sites)-bad_idx)

out = []
for i in ok:
    out.append([pos[i], yvals[i], xvals[i]])
json.dump(out, open('test.data.LD.json', 'w'), indent=2)

pairs = []
for p, y, x in out:
    theta,rho = map(str, y)
    q = open('ldhat.data/'+theta+'_'+rho+'_fas', 'w')
    r = open('ldhat.data/'+theta+'_'+rho+'_loc', 'w')
    pairs.append(['ldhat.data/'+theta+'_'+rho+'_fas', 'ldhat.data/'+theta+'_'+rho+'_loc'])
    m = [' '.join(map(str, [len(p), 20000, 'L']))]
    p2 = [str(round(ii*20000,4)) for ii in p]
    m.append('\n'.join(p2))
    r.write('\n'.join(m))
    r.close()
    n = [' '.join(map(str, [50, len(p), 1]))]
    for idx, i in enumerate(x):
        k = '>hap'+str(idx)+'\n'
        n.append(k+i)
    q.write('\n'.join(n))
    q.close()
    
s = sorted(pairs)
b = open('ldhat.data/pairs.txt' ,'w')
for i,j in s:
    b.write(i+','+j+'\n')
b.close()